package org.serratec.projeto_service_dto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoServiceDtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
