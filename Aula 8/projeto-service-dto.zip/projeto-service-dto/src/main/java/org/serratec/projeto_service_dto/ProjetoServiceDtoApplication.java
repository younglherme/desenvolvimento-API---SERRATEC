package org.serratec.projeto_service_dto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoServiceDtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoServiceDtoApplication.class, args);
	}

}
